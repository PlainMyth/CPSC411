//
//  MovieNightApp.swift
//  MovieNight
//
//  Created by Sebastian C on 10/29/25.
//

import SwiftUI

@main
struct MovieNightApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
